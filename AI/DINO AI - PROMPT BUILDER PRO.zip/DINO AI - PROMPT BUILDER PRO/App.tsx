
import React, { useState, useEffect } from 'react';
import { InputSection } from './components/InputSection';
import { TipWidget } from './components/TipWidget';
import { Icons } from './components/icons';
import { lightingTags, moodToneTags, styleTags, technicalTags, defaultPresets } from './constants';
import type { Preset } from './types';

const FluxPromptBuilder: React.FC = () => {
    // --- STATE CƠ BẢN ---
    const [subject, setSubject] = useState('');
    const [action, setAction] = useState('');
    const [environment, setEnvironment] = useState('');
    const [lighting, setLighting] = useState('');
    const [moodTone, setMoodTone] = useState('');
    const [style, setStyle] = useState('');
    const [technical, setTechnical] = useState('');
    const [extra, setExtra] = useState('');
    
    const [finalPrompt, setFinalPrompt] = useState('');
    const [jsonOutput, setJsonOutput] = useState('');
    const [outputMode, setOutputMode] = useState<'text' | 'json'>('text');
    const [copied, setCopied] = useState(false);

    // --- STATE CHO CUSTOM PRESET ---
    const [customName, setCustomName] = useState('');
    const [customStyle, setCustomStyle] = useState('');
    const [showCustomInput, setShowCustomInput] = useState(false);

    const [presets, setPresets] = useState<Preset[]>(defaultPresets);

    useEffect(() => {
        const parts = [
            subject.trim(),
            action.trim(),
            environment.trim(),
            lighting.trim(),
            moodTone.trim(),
            style.trim(),
            technical.trim(),
            extra.trim()
        ].filter(part => part !== '');

        const prompt = parts.join(', ');
        setFinalPrompt(prompt);

        const jsonObj = {
            subject: subject.trim(),
            action: action.trim(),
            environment: environment.trim(),
            lighting: lighting.trim(),
            mood_tone: moodTone.trim(),
            style: style.trim(),
            technical: technical.trim(),
            extra_details: extra.trim(),
            full_prompt: prompt 
        };
        setJsonOutput(JSON.stringify(jsonObj, null, 2));

    }, [subject, action, environment, lighting, moodTone, style, technical, extra]);

    const handleCopy = () => {
        const textToCopy = outputMode === 'text' ? finalPrompt : jsonOutput;
        navigator.clipboard.writeText(textToCopy).then(() => {
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }).catch(err => {
            console.error('Could not copy text: ', err);
        });
    };

    const clearAll = () => {
        setSubject('');
        setAction('');
        setEnvironment('');
        setLighting('');
        setMoodTone('');
        setStyle('');
        setTechnical('');
        setExtra('');
    };

    const applyPreset = (presetId: string) => {
        const preset = presets.find(p => p.id === presetId);
        if (!preset) return;

        if (preset.values.style) setStyle(prev => preset!.values.style!);
        if (preset.values.lighting) setLighting(prev => preset!.values.lighting!);
        if (preset.values.moodTone) setMoodTone(prev => preset!.values.moodTone!);
        if (preset.values.technical) setTechnical(prev => preset!.values.technical!);
        if (preset.values.environment) setEnvironment(prev => preset!.values.environment!);
    };

    const handleAddCustomPreset = () => {
        if (!customName.trim() || !customStyle.trim()) return;

        const newPreset: Preset = {
            id: `custom_${Date.now()}`,
            label: customName,
            desc: 'Custom Preset',
            icon: <Icons.Tag size={14} className="text-yellow-400" />,
            values: {
                style: customStyle,
            }
        };

        setPresets([...presets, newPreset]);
        setCustomName('');
        setCustomStyle('');
        setShowCustomInput(false);
    };

    return (
        <div className="p-4 md:p-8 max-w-7xl mx-auto">
            
            <header className="mb-8 text-center">
                <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent mb-2 inline-block">
                    DINO AI | Prompt Builder Pro
                </h1>
                <p className="text-slate-400">Công cụ hỗ trợ viết prompt tối ưu cho mọi nền tảng (Flux, MJ, DALL-E, SD...)</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                <div className="lg:col-span-7 space-y-6">
                    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700 shadow-lg">
                        <div className="flex justify-between items-center mb-3">
                            <h3 className="text-sm font-bold text-slate-300 flex items-center gap-2">
                                <Icons.Wand2 size={16} /> Chọn nhanh phong cách (Presets)
                            </h3>
                            <button 
                                onClick={clearAll}
                                className="px-2 py-1 bg-red-900/30 hover:bg-red-900/50 text-red-200 rounded text-xs border border-red-900/50 transition flex items-center gap-1"
                            >
                                <Icons.Trash2 size={12} /> Reset
                            </button>
                        </div>
                        
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 mb-4">
                            {presets.map((preset) => (
                                <button 
                                    key={preset.id}
                                    onClick={() => applyPreset(preset.id)}
                                    className="relative px-2 py-2 bg-slate-800 hover:bg-orange-600 hover:border-orange-500 rounded-lg text-xs border border-slate-700 transition flex flex-col items-center justify-center gap-1 text-center h-16 group"
                                >
                                    <span className="text-slate-400 group-hover:text-white transition-colors">{preset.icon}</span>
                                    <span className="group-hover:text-white font-medium truncate w-full px-1 transition-colors">{preset.label}</span>
                                    {preset.id.startsWith('custom') && (
                                        <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-yellow-500 rounded-full"></span>
                                    )}
                                    <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 w-max max-w-[150px] bg-black text-white text-[10px] p-2 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 shadow-xl border border-slate-700">
                                        {preset.desc}
                                        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-black"></div>
                                    </div>
                                </button>
                            ))}
                            
                            {!showCustomInput && (
                                <button 
                                    onClick={() => setShowCustomInput(true)}
                                    className="px-2 py-2 bg-slate-800/50 hover:bg-slate-700 border border-dashed border-slate-600 rounded-lg text-xs transition flex flex-col items-center justify-center gap-1 text-center h-16 text-slate-500 hover:text-slate-300"
                                >
                                    <Icons.Plus size={16} />
                                    <span>Thêm Mới</span>
                                </button>
                            )}
                        </div>

                        {showCustomInput && (
                            <div className="mt-3 pt-3 border-t border-slate-700 animate-fade-in">
                                <h4 className="text-xs font-bold text-slate-400 mb-2 uppercase tracking-wider">Tạo Preset Tùy Chỉnh</h4>
                                <div className="flex flex-col gap-2">
                                    <input
                                        type="text"
                                        value={customName}
                                        onChange={(e) => setCustomName(e.target.value)}
                                        placeholder="Tên Preset (VD: Gothic Dark)"
                                        className="bg-slate-900 border border-slate-600 rounded p-2 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-white"
                                    />
                                    <input
                                        type="text"
                                        value={customStyle}
                                        onChange={(e) => setCustomStyle(e.target.value)}
                                        placeholder="Nội dung Style (VD: gothic architecture, dark atmosphere...)"
                                        className="bg-slate-900 border border-slate-600 rounded p-2 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-white"
                                    />
                                    <div className="flex gap-2 mt-1">
                                        <button 
                                            onClick={handleAddCustomPreset}
                                            className="flex-1 bg-blue-600 hover:bg-blue-500 text-white text-xs py-1.5 rounded flex items-center justify-center gap-1"
                                        >
                                            <Icons.Save size={12} /> Lưu Preset
                                        </button>
                                        <button 
                                            onClick={() => setShowCustomInput(false)}
                                            className="px-3 bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs py-1.5 rounded"
                                        >
                                            Hủy
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700 space-y-5 shadow-lg">
                        <InputSection label="1. Chủ thể (Subject)" value={subject} setValue={setSubject} placeholder="Ví dụ: A sleek silver sports car, a young woman with curly red hair..." tip="Quan trọng nhất! Các model hiện đại (Midjourney, Flux) rất giỏi hiểu mô tả chi tiết về nhân vật (quần áo, tóc, mắt) và cảm xúc." />
                        <InputSection label="2. Hành động / Tư thế (Action)" value={action} setValue={setAction} placeholder="Ví dụ: racing along the road, reading a book, standing confidently..." tip="Sử dụng động từ mạnh (running, flying). Với DALL-E 3 và Flux, mô tả tương tác vật lý càng cụ thể càng tốt." />
                        <InputSection label="3. Bối cảnh / Môi trường (Environment)" value={environment} setValue={setEnvironment} placeholder="Ví dụ: on a coastal highway, inside a cozy cafe, cyberpunk city..." tip="Xác định không gian. Thêm chi tiết tiền cảnh (foreground) và hậu cảnh (background) để tạo chiều sâu cho ảnh." />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                            <InputSection label="4. Ánh sáng (Lighting)" value={lighting} setValue={setLighting} placeholder="Ví dụ: sunset, cinematic lighting, neon lights, volumetric fog..." tip="Ánh sáng tạo nên 'mood'. Thử các từ khóa: Cinematic, Volumetric (tạo luồng sáng), Rembrandt (tương phản), Golden Hour." options={lightingTags} />
                            <InputSection label="5. Mood / Tone Màu (Color Grading)" value={moodTone} setValue={setMoodTone} placeholder="Ví dụ: Teal and Orange, Noir, Wes Anderson Pastel..." tip="Quyết định màu sắc chủ đạo của bức ảnh. Rất quan trọng để tạo cảm giác điện ảnh." options={moodToneTags} />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                            <InputSection label="6. Phong cách (Style)" value={style} setValue={setStyle} placeholder="Ví dụ: hyper-realistic, oil painting, 3d render, anime style..." tip="Xác định phương tiện nghệ thuật: Ảnh chụp (Photography), Tranh vẽ (Illustration), 3D Render hay Phim hoạt hình." options={styleTags} />
                            <InputSection label="7. Kỹ thuật (Góc máy/Cỡ cảnh)" value={technical} setValue={setTechnical} placeholder="Wide Angle, Portrait, Drone View..." tip="Dùng thuật ngữ nhiếp ảnh: 'Macro' (cận cảnh), 'Wide Angle' (góc rộng), 'Bokeh' (xóa phông) để kiểm soát bố cục." options={technicalTags} />
                        </div>
                        <InputSection label="8. Chi tiết bổ sung (Extra)" value={extra} setValue={setExtra} placeholder="Tham số riêng (VD: --stylize cho MJ, seed cho Flux) hoặc chất lượng (8k, masterpiece)..." />
                    </div>
                </div>

                <div className="lg:col-span-5 flex flex-col gap-6">
                    <div className="sticky top-6">
                        <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-1 shadow-lg border border-slate-700">
                            <div className="bg-slate-900 rounded-lg p-6 h-full flex flex-col">
                                <div className="flex justify-between items-center mb-4">
                                    <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                        <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                                        Kết quả
                                    </h2>
                                    <div className="flex bg-slate-800 rounded-lg p-1 border border-slate-700">
                                        <button onClick={() => setOutputMode('text')} className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-all ${outputMode === 'text' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}>
                                            <Icons.FileText size={14} /> Text
                                        </button>
                                        <button onClick={() => setOutputMode('json')} className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-all ${outputMode === 'json' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}>
                                            <Icons.FileJson size={14} /> JSON
                                        </button>
                                    </div>
                                </div>
                                <div className="relative group flex-grow">
                                    <textarea readOnly value={outputMode === 'text' ? finalPrompt : jsonOutput} className={`w-full h-80 bg-slate-950 p-4 rounded-lg text-slate-300 leading-relaxed resize-none border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono text-sm ${outputMode === 'json' ? 'text-xs' : ''}`} placeholder="Kết quả sẽ hiện ở đây..." />
                                    <div className="absolute bottom-4 right-4 flex items-center gap-3">
                                        <span className="text-xs text-slate-600">
                                            {outputMode === 'text' ? finalPrompt.length : jsonOutput.length} ký tự
                                        </span>
                                        <button onClick={handleCopy} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium text-xs transition-all shadow-lg ${copied ? 'bg-green-600 text-white' : 'bg-blue-600 hover:bg-blue-500 text-white'}`}>
                                            {copied ? <Icons.Check size={14} /> : <Icons.Copy size={14} />}
                                            {copied ? 'Đã chép' : 'Sao chép'}
                                        </button>
                                    </div>
                                </div>
                                <div className="mt-4 p-4 bg-blue-900/20 border border-blue-900/50 rounded-lg">
                                    <h3 className="text-blue-400 text-sm font-bold mb-2 flex items-center gap-2">
                                        <Icons.Info size={14} /> {outputMode === 'text' ? 'Tại sao cấu trúc này hiệu quả?' : 'JSON dùng để làm gì?'}
                                    </h3>
                                    <p className="text-xs text-slate-400">
                                        {outputMode === 'text' ? 'Hầu hết các model AI hiện đại (Midjourney v6, DALL-E 3, Flux) đều được huấn luyện trên caption chi tiết. Việc viết prompt theo cấu trúc ngữ nghĩa tự nhiên giúp AI "hiểu" bối cảnh tốt hơn là chỉ ghép từ khóa.' : 'Định dạng JSON hữu ích để lưu trữ, chia sẻ hoặc dùng với API.'}
                                    </p>
                                </div>
                            </div>
                        </div>
                        <TipWidget />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default FluxPromptBuilder;
