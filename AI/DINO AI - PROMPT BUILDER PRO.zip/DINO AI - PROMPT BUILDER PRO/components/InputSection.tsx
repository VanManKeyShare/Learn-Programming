
import React from 'react';
import { Icons } from './icons';

interface InputSectionProps {
    label: string;
    value: string;
    setValue: (value: string) => void;
    placeholder: string;
    tip?: string;
    options?: string[];
}

export const InputSection: React.FC<InputSectionProps> = ({ label, value, setValue, placeholder, tip, options }) => {
    const toggleOption = (opt: string) => {
        let currents = value.split(',').map(s => s.trim()).filter(s => s !== '');
        if (currents.includes(opt)) {
            currents = currents.filter(c => c !== opt);
        } else {
            currents.push(opt);
        }
        setValue(currents.join(', '));
    };

    const isSelected = (opt: string) => {
        const currents = value.split(',').map(s => s.trim());
        return currents.includes(opt);
    };

    return (
        <div className="flex flex-col gap-2 group">
            <div className="flex justify-between items-center">
                <label className="text-sm font-semibold text-blue-300 group-hover:text-blue-400 transition-colors">
                    {label}
                </label>
                {tip && (
                    <div className="relative group/tooltip">
                        <Icons.Info size={14} className="text-slate-600 cursor-help" />
                        <div className="absolute right-0 bottom-full mb-2 w-72 bg-slate-950 text-xs text-slate-300 p-3 rounded-lg shadow-xl border border-slate-700 opacity-0 group-hover/tooltip:opacity-100 transition-opacity pointer-events-none z-20">
                            {tip}
                        </div>
                    </div>
                )}
            </div>
            <textarea
                value={value}
                onChange={(e) => setValue(e.target.value)}
                className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all min-h-[80px] placeholder-slate-600"
                placeholder={placeholder}
            />
            {options && options.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-1">
                    {options.map((opt, idx) => {
                        const active = isSelected(opt);
                        return (
                            <button
                                key={idx}
                                onClick={() => toggleOption(opt)}
                                className={`text-[10px] px-2 py-1 rounded-full border transition-all flex items-center gap-1 ${
                                    active 
                                    ? 'bg-blue-600 border-blue-500 text-white' 
                                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500 hover:text-slate-200'
                                }`}
                            >
                                {active && <Icons.Check size={10} />}
                                {opt}
                            </button>
                        )
                    })}
                </div>
            )}
        </div>
    );
};
