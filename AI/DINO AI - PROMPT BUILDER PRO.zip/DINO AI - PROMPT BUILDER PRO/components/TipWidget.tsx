
import React, { useState, useEffect } from 'react';
import { tips } from '../constants';
import { Icons } from './icons';

export const TipWidget: React.FC = () => {
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        setCurrentIndex(Math.floor(Math.random() * tips.length));
    }, []);

    const nextTip = () => {
        setCurrentIndex((prev) => (prev + 1) % tips.length);
    };

    const prevTip = () => {
        setCurrentIndex((prev) => (prev - 1 + tips.length) % tips.length);
    };

    const randomTip = () => {
         let newIndex;
         do {
             newIndex = Math.floor(Math.random() * tips.length);
         } while (newIndex === currentIndex); // Avoid showing the same tip twice in a row
         setCurrentIndex(newIndex);
    }

    const currentTip = tips[currentIndex];

    return (
        <div className="mt-6 bg-slate-800/50 rounded-xl border border-slate-700 shadow-lg overflow-hidden flex flex-col">
            <div className="bg-slate-800 p-3 border-b border-slate-700 flex justify-between items-center">
                <h3 className="font-bold text-sm text-blue-300 flex items-center gap-2">
                    <Icons.Lightbulb size={16} className="text-yellow-400"/>
                    Kho Ý Tưởng & Mẹo Prompt ({currentIndex + 1}/{tips.length})
                </h3>
                <div className="flex gap-2">
                     <button 
                        onClick={randomTip}
                        className="text-xs flex items-center gap-1 text-slate-400 hover:text-white transition-colors bg-slate-700/50 px-2 py-1 rounded"
                        title="Ngẫu nhiên"
                    >
                        <Icons.Shuffle size={12}/> Random
                    </button>
                </div>
            </div>
            
            <div className="p-6 flex-grow flex flex-col justify-center min-h-[160px] bg-gradient-to-br from-slate-900 to-slate-800">
                <div className="flex items-start gap-3">
                    <span className="text-4xl text-slate-700 font-serif">“</span>
                    <div>
                        <h4 className="text-lg font-bold text-white mb-2 text-blue-100">{currentTip.title}</h4>
                        <p className="text-sm text-slate-300 leading-relaxed">
                            {currentTip.content}
                        </p>
                    </div>
                </div>
            </div>

            <div className="bg-slate-800/30 p-2 border-t border-slate-700 flex justify-between items-center">
                <button 
                    onClick={prevTip}
                    className="px-3 py-1.5 hover:bg-slate-700 rounded text-xs text-slate-300 flex items-center gap-1 transition-colors"
                >
                    <Icons.ArrowLeft size={12} /> Trước
                </button>
                
                <div className="flex-grow flex justify-center items-center">
                    <div className="h-1 w-24 bg-slate-700 rounded-full overflow-hidden">
                        <div 
                            className="h-full bg-blue-500 transition-all duration-300"
                            style={{ width: `${((currentIndex + 1) / tips.length) * 100}%` }}
                        ></div>
                    </div>
                </div>

                <button 
                    onClick={nextTip}
                    className="px-3 py-1.5 hover:bg-slate-700 rounded text-xs text-slate-300 flex items-center gap-1 transition-colors"
                >
                    Tiếp <Icons.ArrowRight size={12} />
                </button>
            </div>
        </div>
    );
};
