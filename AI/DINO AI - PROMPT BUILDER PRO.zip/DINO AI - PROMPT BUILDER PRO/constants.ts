
import React from 'react';
import { Icons } from './components/icons';
import type { Tip, Preset } from './types';

export const lightingTags: string[] = [
    "Golden Hour", "Cinematic Lighting", "Studio Lighting", "Natural Light", 
    "Volumetric Fog", "Neon Lights", "Bioluminescence", "Soft Lighting", 
    "Hard Shadows", "Rim Light", "Dark Atmosphere", "God Rays"
];

export const moodToneTags: string[] = [
    "Teal and Orange", "Wes Anderson Pastel", "Noir / Monochrome", "Vintage Kodak Portra", 
    "Cyberpunk Neon", "Bleach Bypass", "Technicolor", "Sepia Tone", 
    "Matrix Green Tint", "Warm / Golden Tone", "Cold / Blue Tone", "Muted Earth Tones",
    "High Contrast", "Vibrant & Saturated", "Dreamy Soft Focus"
];

export const styleTags: string[] = [
    "Photorealistic", "Hyper-realistic", "Anime Style", "Manga",
    "3D Render", "Octane Render", "Unreal Engine 5", 
    "Oil Painting", "Impressionism", "Watercolor", "Charcoal Sketch",
    "Cyberpunk", "Steampunk", "Pixel Art", "Vaporwave",
    "Minimalist", "Flat Design", "Concept Art", "Pop Art",
    "Ukiyo-e", "Gothic", "Surrealism"
];

export const technicalTags: string[] = [
    "Extreme Close-up", "Close-up", "Face Focus", "Portrait", 
    "Headshot", "Shoulder Level", "Upper Body", "Half Body", "Full Body Shot",
    "Wide Angle", "Ultra-Wide Angle", "Telephoto", "Fish-eye Lens", "Macro Lens",
    "Eye Level", "Low Angle", "High Angle", "Bird's Eye View", 
    "Drone View", "Aerial View", "Worm's Eye View", "GoPro Style", "Selfie"
];

export const defaultPresets: Preset[] = [
    {
        id: 'photorealistic',
        label: 'Photorealistic',
        desc: 'Ảnh thật sắc nét',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Camera, { size: 14 }),
        values: {
            style: 'hyper-realistic, 8k resolution, highly detailed, photorealistic texture, raw photo',
            lighting: 'natural soft lighting, cinematic atmosphere',
            moodTone: 'Muted Earth Tones, High Contrast',
            technical: 'shot on 35mm lens, f/1.8, depth of field, sharp focus'
        }
    },
    {
        id: 'anime',
        label: 'Anime',
        desc: 'Hoạt hình Nhật Bản',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Palette, { size: 14 }),
        values: {
            style: 'anime style, vibrant colors, cel shaded, Makoto Shinkai style, high quality illustration',
            lighting: 'bright and airy, lens flare, magical glow',
            moodTone: 'Vibrant & Saturated',
            technical: 'digital art, 2D render'
        }
    },
    {
        id: 'cyberpunk',
        label: 'Cyberpunk',
        desc: 'Tương lai công nghệ cao',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Box, { size: 14 }),
        values: {
            style: 'cyberpunk aesthetic, futuristic, neon details, high tech',
            lighting: 'neon lights, volumetric fog, dark atmosphere with bright accents',
            moodTone: 'Cyberpunk Neon, Cold / Blue Tone',
            environment: 'futuristic city street at night, rain slicked roads',
            technical: 'contrast heavy, chromatic aberration'
        }
    },
    {
        id: 'cinematic',
        label: 'Cinematic',
        desc: 'Điện ảnh, phim bom tấn',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Film, { size: 14 }),
        values: {
            style: 'cinematic movie still, blockbuster look, color graded, dramatic composition',
            lighting: 'dramatic lighting, rim light, moody atmosphere',
            moodTone: 'Teal and Orange',
            technical: 'anamorphic lens, wide aspect ratio, film grain'
        }
    },
    {
        id: '3d_render',
        label: '3D Animation',
        desc: 'Hoạt hình 3D kiểu Pixar',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Box, { size: 14 }),
        values: {
            style: 'Pixar style, 3d render, unreal engine 5, cute, volumetric lighting, cgsociety',
            lighting: 'soft studio lighting, warm atmosphere, global illumination',
            moodTone: 'Vibrant & Saturated',
            technical: 'octane render, ray tracing, 4k'
        }
    },
    {
        id: 'fantasy',
        label: 'Fantasy',
        desc: 'Thế giới giả tưởng, phép thuật',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Wand2, { size: 14 }),
        values: {
            style: 'digital fantasy art, D&D style, intricate details, majestic, epic scale',
            lighting: 'mystical glow, ethereal lighting, bioluminescence',
            moodTone: 'Dreamy Soft Focus',
            technical: 'highly detailed masterpiece, matte painting'
        }
    },
    {
        id: 'vintage',
        label: 'Vintage',
        desc: 'Cổ điển, hoài niệm',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Camera, { size: 14 }),
        values: {
            style: 'vintage 1980s photo, analog film, polaroid style, nostalgia, retro fashion',
            lighting: 'flash photography, harsh shadows or faded light',
            moodTone: 'Vintage Kodak Portra, Sepia Tone',
            technical: 'film grain, light leaks, slightly blurred, vhs glitch'
        }
    },
    {
        id: 'oil_painting',
        label: 'Oil Painting',
        desc: 'Tranh sơn dầu nghệ thuật',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Palette, { size: 14 }),
        values: {
            style: 'oil painting, thick brushstrokes, impressionist style, textured canvas, classical art',
            lighting: 'chiaroscuro, painterly light',
            moodTone: 'Warm / Golden Tone',
            technical: 'traditional medium imitation'
        }
    },
    {
        id: 'documentary',
        label: 'Documentary',
        desc: 'Phim tài liệu chân thực',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Film, { size: 14 }),
        values: {
            style: 'documentary footage, 16mm film grain, raw style, journalism, handheld camera',
            lighting: 'natural lighting, harsh sunlight or overcast',
            moodTone: 'Muted Earth Tones, Desaturated',
            technical: '4k, sharp focus, realistic texture'
        }
    },
    {
        id: 'horror',
        label: 'Horror',
        desc: 'Kinh dị, rùng rợn',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Wand2, { size: 14 }),
        values: {
            style: 'horror movie still, ominous, eerie, unsettling, dark fantasy',
            lighting: 'low key lighting, deep shadows, flickering light',
            moodTone: 'Cold / Blue Tone, Desaturated',
            technical: 'film grain, vignette, slightly blurred edges'
        }
    },
    {
        id: 'stop_motion',
        label: 'Stop Motion',
        desc: 'Hoạt hình đất sét',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Box, { size: 14 }),
        values: {
            style: 'stop motion animation, claymation, Aardman style, handmade texture, plasticine',
            lighting: 'studio lighting, soft shadows',
            moodTone: 'Vibrant & Saturated',
            technical: 'tilt-shift effect, miniature faking, macro lens'
        }
    },
    {
        id: 'noir',
        label: 'Film Noir',
        desc: 'Phim đen trắng nghệ thuật',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Film, { size: 14 }),
        values: {
            style: 'film noir, black and white photography, classic cinema, detective movie',
            lighting: 'chiaroscuro, hard shadows, silhouette, dramatic lighting',
            moodTone: 'Noir / Monochrome, High Contrast',
            technical: 'black and white, high contrast, 35mm film'
        }
    },
    {
        id: 'comic',
        label: 'Comic Book',
        desc: 'Truyện tranh, Graphic Novel',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Palette, { size: 14 }),
        values: {
            style: 'comic book art, graphic novel style, bold lines, cel shaded, Marvel/DC style',
            lighting: 'dynamic lighting, strong contrast',
            moodTone: 'Vibrant & Saturated, Halftone',
            technical: '2D illustration, ink lines'
        }
    },
    {
        id: 'retro_vhs',
        label: 'Retro VHS',
        desc: 'Băng từ thập niên 90',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Camera, { size: 14 }),
        values: {
            style: 'vintage 90s footage, vhs glitch, analog video, distorted, home video',
            lighting: 'flash photography, harsh light',
            moodTone: 'Cyberpunk Neon, Faded',
            technical: 'low resolution, scanlines, chromatic aberration'
        }
    },
    {
        id: 'product',
        label: 'Product Shot',
        desc: 'Chụp sản phẩm quảng cáo',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Box, { size: 14 }),
        values: {
            style: 'professional product photography, studio setup, commercial, luxury',
            lighting: 'soft studio lighting, rim light, perfect lighting',
            moodTone: 'Vibrant & Saturated, Clean',
            technical: '4k, sharp focus, macro lens, depth of field'
        }
    },
    {
        id: 'double_exposure',
        label: 'Double Exposure',
        desc: 'Lồng ghép ảnh nghệ thuật',
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        icon: React.createElement(Icons.Wand2, { size: 14 }),
        values: {
            style: 'double exposure, multiple exposure, surreal art, dreamlike, movie intro style',
            lighting: 'dreamy lighting, silhouette',
            moodTone: 'Dreamy Soft Focus, High Contrast',
            technical: 'artistic composition, overlay'
        }
    }
];

export const tips: Tip[] = [
    { title: "Ánh sáng Rembrandt", content: "Sử dụng 'Rembrandt lighting' để tạo khối mặt ấn tượng với một hình tam giác sáng nhỏ trên má đối diện nguồn sáng (kinh điển cho chân dung)." },
    { title: "Luồng sáng thần thánh (God Rays)", content: "Dùng 'Volumetric lighting', 'God rays' hoặc 'Tyndall effect' để tạo các luồng sáng xuyên qua khói, bụi hoặc kẽ lá." },
    { title: "Ánh sáng ven (Rim Light)", content: "'Rim light' hoặc 'Backlight' giúp tách chủ thể ra khỏi nền tối bằng một đường viền sáng bao quanh tóc và vai." },
    { title: "Ánh sáng mềm (Softbox)", content: "'Soft studio lighting', 'Diffused light' tạo ra bóng đổ mềm mại, da dẻ mịn màng, rất hợp chụp thời trang." },
    { title: "Ánh sáng gắt (Hard Light)", content: "'Hard shadows', 'Direct sunlight' tạo tương phản mạnh, kịch tính, phù hợp phong cách Noir hoặc mùa hè rực rỡ." },
    { title: "Giờ vàng (Golden Hour)", content: "Thời điểm mặt trời mọc/lặn. Từ khóa 'Golden hour' mang lại tone màu vàng ấm áp, da dẻ hồng hào." },
    { title: "Giờ xanh (Blue Hour)", content: "Thời điểm chập choạng tối. 'Blue hour' tạo không khí lạnh lẽo, tĩnh lặng và huyền bí." },
    { title: "Phát quang sinh học", content: "'Bioluminescence' tạo ra các sinh vật, cây cối tự phát sáng (màu xanh neon/tím) trong đêm tối." },
    { title: "Ánh sáng Neon Cyberpunk", content: "Kết hợp 'Neon lights', 'Cyberpunk lighting' với màu Cyan và Magenta để tạo chất Sci-fi." },
    { title: "Tương phản Chiaroscuro", content: "'Chiaroscuro' là kỹ thuật dùng tương phản cực mạnh giữa sáng và tối (phong cách tranh Caravaggio)." },
    { title: "Ánh sáng hắt (Bounce Light)", content: "'Bounce lighting' hoặc 'Global illumination' giúp ánh sáng lan tỏa tự nhiên vào các vùng tối." },
    { title: "Ánh sáng lập lòe", content: "'Flickering candlelight' hoặc 'Firelight' tạo không khí ấm cúng, thân mật hoặc ma mị." },
    { title: "Bóng đổ hoa văn (Gobo)", content: "Dùng 'Gobo lighting' hoặc 'Window blind shadows' để tạo bóng đổ hình rèm cửa/cây cối lên mặt chủ thể." },
    { title: "Phơi sáng dài (Long Exposure)", content: "'Long exposure', 'Light trails' để tạo vệt sáng xe chạy hoặc dòng nước mượt như lụa." },
    { title: "Ánh sáng dưới nước", content: "'Caustics' hoặc 'Underwater refraction' tạo hiệu ứng vân sáng nhảy múa dưới đáy nước." },
    { title: "Góc máy thấp (Low Angle)", content: "'Low angle shot' hoặc 'Worm's eye view' làm chủ thể trông khổng lồ, quyền lực và áp đảo." },
    { title: "Góc máy cao (High Angle)", content: "'High angle shot' hoặc 'Bird's eye view' làm chủ thể trông nhỏ bé, yếu đuối hoặc dùng để tả toàn cảnh." },
    { title: "Góc nghiêng Dutch", content: "'Dutch angle' (nghiêng máy) tạo cảm giác bất ổn, chóng mặt, kịch tính hoặc hành động nhanh." },
    { title: "Góc nhìn qua vai", content: "'Over-the-shoulder shot' tạo cảm giác như người xem đang đứng ngay sau nhân vật, tăng tính nhập vai." },
    { title: "Góc nhìn thứ nhất (POV)", content: "'POV shot', 'First-person view' hoặc 'GoPro footage' cho trải nghiệm trực tiếp từ mắt nhân vật." },
    { title: "Quy tắc 1/3", content: "'Rule of thirds' yêu cầu AI đặt chủ thể ở 1/3 khung hình thay vì chính giữa, tạo bố cục nghệ thuật hơn." },
    { title: "Đường dẫn hướng", content: "'Leading lines' sử dụng con đường, hàng rào... để dẫn mắt người xem vào chủ thể chính." },
    { title: "Khung trong khung", content: "'Frame within a frame' (nhìn qua cửa sổ, vòm hang) để tập trung sự chú ý và tạo chiều sâu." },
    { title: "Bố cục đối xứng", content: "'Symmetrical composition' hoặc 'Wes Anderson style' tạo cảm giác cân bằng, hoàn hảo và hơi kỳ quặc." },
    { title: "Khoảng trống (Negative Space)", content: "'Negative space' hoặc 'Minimalist composition' để nhiều khoảng trống xung quanh chủ thể." },
    { title: "Cận cảnh cực đại", content: "'Extreme close-up' hoặc 'Macro photography' để soi rõ lỗ chân lông, mắt côn trùng hoặc gân lá." },
    { title: "Góc rộng (Wide Angle)", content: "'Wide angle', '16mm lens' lấy được nhiều bối cảnh nhưng làm méo hình ở rìa (hiệu ứng hùng vĩ)." },
    { title: "Tiêu cự Tele", content: "'Telephoto lens', '200mm lens' giúp xóa phông mù mịt và làm chủ thể nổi bật, ép phẳng hậu cảnh." },
    { title: "Sắp xếp Knolling", content: "'Knolling' là phong cách sắp xếp các vật thể vuông vắn, tách biệt trên nền phẳng (rất hợp chụp sản phẩm)." },
    { title: "Góc nhìn cắt bổ (Cross-section)", content: "'Cutaway', 'Cross-section' hiển thị cấu tạo bên trong của tòa nhà, máy móc hoặc cơ thể." },
    { title: "Chất liệu lấp lánh", content: "'Iridescent', 'Holographic' hoặc 'Opalescent' tạo bề mặt đổi màu như xà cừ hoặc đĩa CD." },
    { title: "Kim loại lỏng", content: "'Liquid metal', 'Chrome', 'Mercury' tạo cảm giác vật thể chảy ra, bóng loáng như gương." },
    { title: "Da sứ (Porcelain)", content: "'Porcelain skin', 'Ball-jointed doll' tạo làn da trắng mịn, bóng nhẹ, hoàn hảo nhưng hơi vô hồn." },
    { title: "Chất liệu bán trong suốt", content: "'Translucent', 'Subsurface scattering' (SSS) dùng cho sáp, thạch, lá cây để ánh sáng xuyên qua nhẹ." },
    { title: "Kỹ thuật Impasto", content: "'Impasto oil painting' tạo ra các nét cọ sơn dầu dày, nổi khối rõ rệt trên tranh." },
    { title: "Màu nước loang", content: "'Wet-on-wet watercolor', 'Ink wash' tạo hiệu ứng màu loang lổ, mềm mại và mộng mơ." },
    { title: "Tranh khắc gỗ Nhật", content: "'Ukiyo-e style', 'Woodblock print' tạo phong cách cổ điển Nhật Bản (nét viền đen, màu bệt)." },
    { title: "Nghệ thuật cắt giấy", content: "'Layered paper art', 'Paper cut craft' tạo hiệu ứng các lớp giấy chồng lên nhau đổ bóng sâu." },
    { title: "Cyberpunk Vibe", content: "Công thức: 'Neon lights' + 'Rain' + 'Reflective wet streets' + 'High-tech low-life'." },
    { title: "Steampunk", content: "Kết hợp 'Brass gears' (bánh răng đồng), 'Steam' (hơi nước), kính bảo hộ và thời trang Victoria." },
    { title: "Solarpunk", content: "Tương lai xanh: 'Art Nouveau architecture', 'Greenery', 'Solar panels', 'Bright utopia'." },
    { title: "Vaporwave", content: "Thẩm mỹ 90s: 'Windows 95 UI', 'Roman statues', 'Grid floor', 'Pastel pink & purple'." },
    { title: "Pixel Art", content: "Thêm '16-bit', 'Pixel art', 'Sprite sheet' cho phong cách game cổ điển." },
    { title: "Kinh dị Lovecraft", content: "'Eldritch horror', 'Cosmic horror', 'Tentacles' tạo cảm giác sợ hãi trước những thứ không thể diễn tả." },
    { title: "Low Poly", content: "'Low poly 3D', 'Isometric' tạo hình khối đơn giản, góc cạnh như game mobile." },
    { title: "Thủy tinh thổi", content: "'Blown glass sculpture', 'Murano glass' tạo hình khối uốn lượn, trong suốt và nhiều màu." },
    { title: "Len nỉ (Felting)", content: "'Needle felting', 'Fuzzy texture' tạo ra các nhân vật bằng len xù lông dễ thương." },
    { title: "Gốm Kintsugi", content: "'Kintsugi' là nghệ thuật sửa gốm vỡ bằng vàng, tạo các đường nứt vàng tuyệt đẹp." },
    { title: "Mô hình Tamiya", content: "'Plastic model kit', 'Tamiya box art' tạo phong cách hộp đồ chơi lắp ráp chi tiết." },
    { title: "Bản vẽ kỹ thuật", content: "'Blueprint', 'Schematic', 'Patent drawing' vẽ các đường nét trắng trên nền xanh." },
    { title: "MJ: Stylize (--s)", content: "--s 0 đến 1000. --s 50 (bám sát prompt), --s 250 (mặc định), --s 750-1000 (rất nghệ thuật nhưng có thể xa rời prompt)." },
    { title: "MJ: Chaos (--c)", content: "--c 0 đến 100. --c càng cao, kết quả càng ngẫu nhiên và bất ngờ. Dùng khi bí ý tưởng." },
    { title: "MJ: Weird (--w)", content: "--w 0 đến 3000. Tạo ra những hình ảnh kỳ quái, độc lạ, khác thường." },
    { title: "MJ: Tham chiếu nhân vật", content: "Dùng '--cref https://www.pinterest.com/anh5327/h%C3%ACnh-%E1%BA%A3nh/' để giữ khuôn mặt nhân vật nhất quán qua các ảnh khác nhau." },
    { title: "MJ: Tham chiếu phong cách", content: "Dùng '--sref https://www.pinterest.com/anh5327/h%C3%ACnh-%E1%BA%A3nh/' để copy phong cách màu sắc/nét vẽ của ảnh mẫu sang ảnh mới." },
    { title: "MJ: Loại bỏ (--no)", content: "Dùng '--no glasses', '--no text', '--no blur' để loại bỏ các yếu tố không mong muốn." },
    { title: "MJ: Hoa văn lặp (--tile)", content: "Dùng '--tile' để tạo ra texture liền mạch (seamless pattern) dùng in vải hoặc làm giấy dán tường." },
    { title: "MJ: Tỷ lệ ảnh (--ar)", content: "--ar 16:9 (Youtube), --ar 9:16 (Tiktok), --ar 2:3 (Poster), --ar 21:9 (Ultrawide)." },
    { title: "MJ: Niji Anime", content: "Thêm '--niji 6' vào cuối prompt để kích hoạt model chuyên vẽ Anime cực đẹp của MJ." },
    { title: "MJ: Trọng số (::)", content: "Dùng dấu '::' để chỉnh mức độ quan trọng. VD: 'cat::2 dog::1' (ưu tiên mèo hơn chó)." },
    { title: "MJ: Raw Style", content: "Thêm '--style raw' để giảm bớt bộ lọc thẩm mỹ mặc định của MJ, giúp ảnh trông thật hơn (ít bị 'AI look')." },
    { title: "MJ: Permutation", content: "Dùng dấu ngoặc nhọn để chạy nhiều biến thể. VD: 'a {cat, dog} in space' sẽ tạo 2 lệnh riêng biệt." },
    { title: "MJ: Stop", content: "--stop 80 dừng quá trình render ở 80%, tạo hiệu ứng mờ ảo hoặc chưa hoàn thiện nghệ thuật." },
    { title: "MJ: Video", content: "Thêm '--video' để nhận link video ngắn quay lại quá trình AI vẽ tranh." },
    { title: "MJ: Repeat", content: "--repeat 5 (chỉ bản Pro) để chạy lại prompt đó 5 lần liên tiếp." },
    { title: "MJ: Zoom Out", content: "Sau khi upscale, dùng tính năng 'Zoom Out' để mở rộng bối cảnh xung quanh." },
    { title: "MJ: Pan", content: "Dùng nút mũi tên Pan để mở rộng ảnh sang trái/phải/lên/xuống." },
    { title: "MJ: Vary Region", content: "Dùng 'Vary Region' (Inpainting) để sửa lại một vùng nhỏ trong ảnh (ví dụ đổi cái mũ)." },
    { title: "MJ: Describe", content: "Dùng lệnh /describe và upload ảnh để MJ viết lại prompt cho bạn học hỏi." },
    { title: "MJ: Shorten", content: "Dùng lệnh /shorten [prompt dài] để MJ chỉ ra những từ khóa nào thực sự quan trọng." },
    { title: "Flux: Văn bản (Text)", content: "Flux render chữ cực tốt. Đặt chữ trong ngoặc kép: text \"DINO AI\" on a neon sign. Dùng từ khóa 'bold font', 'serif font'." },
    { title: "Flux: Ngón tay", content: "Flux cải thiện ngón tay đáng kể. Prompt 'holding a cup', 'playing piano' để kiểm chứng." },
    { title: "Flux: Vị trí cụ thể", content: "Flux hiểu vị trí rất tốt. 'A cat on the left, a dog on the right, a bird in the center'." },
    { title: "Flux: Caption tự nhiên", content: "Đừng dùng tag rời rạc. Hãy viết câu văn tả cảnh: 'A photo of a woman sitting in a cafe...'." },
    { title: "DALL-E 3: Chi tiết ẩn", content: "DALL-E 3 tự động viết lại prompt của bạn dài hơn. Bạn có thể yêu cầu: 'I need exact prompt adherence'." },
    { title: "DALL-E 3: Bảng hiệu", content: "Rất giỏi làm poster. Prompt: 'A movie poster with title \"THE END\" in red blood font'." },
    { title: "DALL-E 3: Chia khung", content: "'A 4-panel comic strip showing...' để vẽ truyện tranh 4 khung." },
    { title: "Flux: Độ phân giải", content: "Flux Dev/Pro hỗ trợ độ phân giải rất cao. Thử 'ultra-detailed 8k resolution'." },
    { title: "Flux: Lấy nét", content: "Kiểm soát độ mờ hậu cảnh tốt với 'f/1.4' (mờ nhiều) hoặc 'f/8' (rõ cả nền)." },
    { title: "Phong cách Flat Lay", content: "Flux làm ảnh sắp đặt (Flat lay) rất tốt. 'Knolling layout of camping gear on wooden table'." },
    { title: "Flux: Da thật", content: "Thêm 'skin texture', 'pores', 'imperfections', 'moles' để da không bị láng mịn kiểu nhựa." },
    { title: "Ảnh đời thường (Candid)", content: "'Candid shot', 'Unposed' để nhân vật trông tự nhiên, không nhìn vào ống kính." },
    { title: "Góc nhìn mắt cá", content: "'Shot through a peephole' hoặc 'Fish-eye' tạo hiệu ứng méo mó thú vị." },
    { title: "Ảnh giám sát (CCTV)", content: "'CCTV footage', 'Grainy', 'Low quality', 'Timestamp' tạo cảm giác ảnh camera an ninh." },
    { title: "Ảnh tin tức", content: "'Associated Press photo', 'Photojournalism style' tạo cảm giác ảnh báo chí chân thực." },
    { title: "Màu Teal & Orange", content: "Tone màu kinh điển Hollywood: 'Teal and Orange grading'. Da người cam ấm nổi bật trên nền xanh lạnh." },
    { title: "Màu Pastel Wes Anderson", content: "Tone màu phấn nhạt, đối xứng: 'Wes Anderson style', 'Pastel pink and mint green'." },
    { title: "Đơn sắc (Monochrome)", content: "Thử 'Blue monochrome' (chỉ các sắc độ xanh) hoặc 'Sepia' (nâu cũ kỹ)." },
    { title: "Màu Neon Acid", content: "'Acid colors', 'Trippy colors' dùng cho phong cách Psychedelic gây ảo giác." },
    { title: "Màu đất (Earth Tones)", content: "'Muted earth tones', 'Beige', 'Olive', 'Rust' tạo cảm giác mộc mạc, thời trang." },
    { title: "Mã màu Hex", content: "Bạn có thể dùng mã màu chính xác: 'Dress in #FF0000 red color'." },
    { title: "Color Splash", content: "'Black and white photo with red umbrella' (chỉ có cái ô là có màu đỏ)." },
    { title: "Phim Kodak Portra", content: "'Shot on Kodak Portra 400' tạo grain mịn và tone màu da rất đẹp, tự nhiên." },
    { title: "Phim Fujifilm Velvia", content: "'Shot on Fujifilm Velvia' cho màu sắc rực rỡ, độ bão hòa cao (thích hợp chụp phong cảnh)." },
    { title: "Phim Ilford HP5", content: "'Shot on Ilford HP5' là phim đen trắng kinh điển, độ tương phản cao và grain rõ." },
    { title: "Hiệu ứng VHS", content: "'VHS glitch', 'Scanlines', 'Chromatic aberration' tạo cảm giác băng từ thập niên 90." },
    { title: "Chi tiết máy móc (Greeble)", content: "'Greeble' là thuật ngữ chỉ các chi tiết máy móc nhỏ thêm vào bề mặt tàu vũ trụ để tăng độ phức tạp." },
    { title: "Vẻ đẹp thoát tục (Ethereal)", content: "'Ethereal', 'Dreamy' tạo ra vẻ đẹp mong manh, mờ ảo như trong giấc mơ." },
    { title: "Thứ tự ưu tiên", content: "AI đọc từ trái sang phải. Luôn đặt chủ thể quan trọng nhất ở đầu câu. Chi tiết phụ để sau." },
    { title: "Lặp lại từ khóa", content: "Nếu AI lờ đi chi tiết nào, hãy nhắc lại nó 2-3 lần hoặc dùng từ đồng nghĩa." }
];