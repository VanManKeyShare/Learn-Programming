
import type React from 'react';

export type Tip = {
  title: string;
  content: string;
};

export type PresetValue = {
  style?: string;
  lighting?: string;
  moodTone?: string;
  technical?: string;
  environment?: string;
};

export type Preset = {
  id: string;
  label: string;
  desc: string;
  icon: React.ReactNode;
  values: PresetValue;
};
