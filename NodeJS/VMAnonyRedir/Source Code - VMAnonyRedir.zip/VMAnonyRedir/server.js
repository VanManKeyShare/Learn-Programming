// SERVER.JS

import "dotenv/config";
import express from "express";
import validUrl from "valid-url";
import helmet from "helmet";

const app = express();
const PORT = process.env.SERVER_PORT || 8080;
const SERVER_HOSTNAME = process.env.SERVER_HOSTNAME || `VMAnonyRedir.domain`;

// BẢO MẬT ỨNG DỤNG BẰNG CÁCH THIẾT LẬP CÁC HTTP HEADERS
app.use(
  helmet({
    contentSecurityPolicy: false, // TẮT NẾU BẠN GẶP VẤN ĐỀ VỚI SCRIPT CỦA EJS
  })
);

app.set("view engine", "ejs");
app.use(express.static("public"));

// ROUTE TRANG CHỦ
app.get("/", (req, res) => {
  res.render("index", { App_Domain: SERVER_HOSTNAME });
});

// MIDDLEWARE XỬ LÝ URL CHUYỂN HƯỚNG
app.use((req, res) => {
  // LẤY URL VÀ LÀM SẠCH KÝ TỰ KHOẢNG TRẮNG/XUYỆT ĐẦU DÒNG NHANH GỌN
  let vmk_url = decodeURIComponent(req.originalUrl).replace(/^\/+/, "").trim();

  if (validUrl.isUri(vmk_url)) {
    return res.render("redir", { Url: vmk_url, App_Domain: SERVER_HOSTNAME });
  }

  // NẾU KHÔNG PHẢI URL HỢP LỆ VÀ KHÔNG TRÙNG ROUTE NÀO, VỀ TRANG CHỦ
  if (!res.headersSent) {
    res.redirect("/");
  }
});

app.listen(PORT, () => {
  console.log(`🚀 SERVER ĐANG CHẠY TẠI: http://LOCALHOST:${PORT}`);
});
